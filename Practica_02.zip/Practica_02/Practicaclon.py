import random
import time
import sys
import matplotlib.pyplot as plt

# Función de partición
def dividir(array, izquierda, derecha):
    pivote = array[izquierda]
    while True:
        while array[izquierda] < pivote:
            izquierda += 1
            if izquierda >= derecha:
                break
        while array[derecha] > pivote:
            derecha -= 1
            if izquierda >= derecha:
                break
        if izquierda >= derecha:
            return derecha
        else:
            array[izquierda], array[derecha] = array[derecha], array[izquierda]
            izquierda += 1
            derecha -= 1

# Función QuickSort
def quicksort(array, izquierda, derecha):
    if izquierda < derecha:
        indice_division = dividir(array, izquierda, derecha)
        quicksort(array, izquierda, indice_division)
        quicksort(array, indice_division + 1, derecha)

# Generación de arreglos
def generar_arreglo():
    n = random.randint(5, 10000)
    a = 0
    b = 100
    arreglo = [random.randint(a, b) for _ in range(n)]
    return arreglo

def medir_tiempo(arreglo):
    inicio = time.time()
    quicksort(arreglo, 0, len(arreglo) - 1)
    fin = time.time()
    return fin - inicio

resultados = []  # Lista para almacenar los tiempos de ejecución

# Medir tiempos de ejecución
for i in range(100):
    arreglo = generar_arreglo()
    tiempo_ejecutado = medir_tiempo(arreglo)
    resultados.append(tiempo_ejecutado)

# Mostrar los 3 tiempos más rápidos
print("Tres tiempos de ejecución más rápidos:")
for i in range(3):
    tiempo = resultados[i]
    print(f"Tiempo: {tiempo:.6f} segundos")

# Mostrar los 3 tiempos de ejecución más lentos
print("\nTres tiempos de ejecución más lentos:")
for i in range(-1, -4, -1):
    tiempo = resultados[i]
    print(f"Tiempo: {tiempo:.6f} segundos")

# Crear un gráfico para visualizar los tiempos
plt.bar(range(len(resultados)), resultados)
plt.xlabel('Número de ejecución')
plt.ylabel('Tiempo de ejecución (segundos)')
plt.title('QuickSort')
plt.show()
